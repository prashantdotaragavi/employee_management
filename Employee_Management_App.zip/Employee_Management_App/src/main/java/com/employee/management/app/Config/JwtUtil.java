package com.employee.management.app.Config;

import java.security.Key;
import java.util.Date;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;

@Component
public class JwtUtil {
    
    private String secretKey = "5367566B59703373367639792F423F4528482B4D6251655468576D5A71347437"; // Replace with your secret key
    private int expirationTime = 3600000; // 1 hour in milliseconds

    // Generate Token
    public String generateToken(Authentication authenticate) {
        UserDetails principal = (UserDetails) authenticate.getPrincipal();
        Date currentDate = new Date();
        Date expireDate = new Date(currentDate.getTime() + expirationTime);
        
        return Jwts.builder()
                .setSubject(principal.getUsername())
                .setIssuedAt(currentDate)
                .setExpiration(expireDate)
                .signWith(SignatureAlgorithm.HS256, secretKey) // Use the signing key
                .compact();
    }
   
    // Extract Username from Token
    public String getUsername(String token) {
        Claims claims = Jwts.parserBuilder()   // Use parserBuilder
                .setSigningKey(key())          // Set the signing key
                .build()                       // Build the JWT parser
                .parseClaimsJws(token)         // Parse the token
                .getBody();                    // Get the claims body
        return claims.getSubject();            // Return the subject (username)
    }
    
    // Validate Token
    public boolean validateToken(String token) {
        try {
            Jwts.parserBuilder()               // Use parserBuilder
                .setSigningKey(key())          // Set the signing key
                .build()                       // Build the parser
                .parseClaimsJws(token);        // Parse the token
            return true;
        } catch (Exception e) {
            // Log exception (optional)
            return false; // Return false if token validation fails
        }
    }

    // Generate the Secret Key
    private Key key() {
        byte[] bytes = Decoders.BASE64.decode(secretKey);
        return Keys.hmacShaKeyFor(bytes); // Generate HMAC-SHA key
    }
}
