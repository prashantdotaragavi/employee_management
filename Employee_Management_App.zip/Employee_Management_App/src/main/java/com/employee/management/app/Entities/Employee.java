package com.employee.management.app.Entities;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.persistence.TableGenerator;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@AllArgsConstructor
@Builder
@NoArgsConstructor
@Table(name = "t_employees")
public class Employee {

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
//	@TableGenerator(name="id_generator", table = "id_gen", pkColumnName = "gen_id", valueColumnName = "gen_value",pkColumnValue = "user_generator",initialValue = 00000, allocationSize = 1)
    private int id;
   
    private String empCode;
    private String firstName;
    private String lastName;
    private String fullName;
    private String email;
    private String phone;
    private LocalDate doj; 
    
    @ManyToOne
    @JoinColumn(name = "organization_id", referencedColumnName = "id")
    private Organization organization;
    
    @ManyToOne
    @JoinColumn(name = "designation_id", referencedColumnName = "id")
    private Designation designation;
    
    private boolean isActive;
    
    private LocalDateTime createdDate;
    private LocalDateTime modifiedDate;
    
    
}