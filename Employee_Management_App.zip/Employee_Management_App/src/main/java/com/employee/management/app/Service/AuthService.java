package com.employee.management.app.Service;
import com.employee.management.app.Payload.ForgotPasswordRequest;
import com.employee.management.app.Payload.ForgotPasswordResponse;
import com.employee.management.app.Payload.LoginRequest;
import com.employee.management.app.Payload.ResetPasswordRequest;
import com.employee.management.app.Payload.ValidateOtpRequest;

public interface AuthService {
    
//	String login(LoginRequest loginRequest);
	ForgotPasswordResponse forgotPassword(ForgotPasswordRequest request);
	void validateOtp(ValidateOtpRequest request);
	void resetPassword(ResetPasswordRequest request);
	void createEmployeeCredentials(Integer employeeId, String password);
	String loginDTO(LoginRequest loginRequest);
	
}

