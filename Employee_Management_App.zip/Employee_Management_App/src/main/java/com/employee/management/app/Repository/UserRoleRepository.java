package com.employee.management.app.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.employee.management.app.Entities.AppUserDetails;
import com.employee.management.app.Entities.UserRole;
import java.util.Optional;
import java.util.Set;

@Repository
public interface UserRoleRepository extends JpaRepository<UserRole, Long> {

    Set<UserRole> findByUserDetails(AppUserDetails userDetails);

    Set<UserRole> findByUserDetailsEmail(@Param("email") String email);
    

}
