package com.employee.management.app.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.employee.management.app.Entities.AppUserDetails;
import com.employee.management.app.Entities.UserRole;

import java.util.Optional;

@Repository
public interface UserDetailsRepository extends JpaRepository<AppUserDetails, Long> {

    Optional<AppUserDetails> findByUsername(String username);

    Optional<AppUserDetails> findByEmail(String email);

    boolean existsByUsername(String username);

    boolean existsByEmail(String email);

	void save(UserRole userRole);
}
