package com.employee.management.app.Payload;

import java.time.LocalDate;
import java.util.Date;

import com.employee.management.app.Entities.Designation;
import com.employee.management.app.Entities.Employee;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class PastExperienceResponseDTO {



	private int id;


//    @NotBlank(message = "Company name is required")
    private String companyName;

//    @NotNull(message = "Start date is required")
    private LocalDate startDate;

//    @NotNull(message = "End date is required")
    private LocalDate endDate;

//    @NotNull(message = "Designation is required")
    private int  designationId;   

    private String responsibilities;
}
