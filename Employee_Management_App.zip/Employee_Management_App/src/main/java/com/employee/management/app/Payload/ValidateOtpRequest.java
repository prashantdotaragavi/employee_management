package com.employee.management.app.Payload;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ValidateOtpRequest {
	
    private Long userId;
    private Long otpId;
    private String otp;
}

