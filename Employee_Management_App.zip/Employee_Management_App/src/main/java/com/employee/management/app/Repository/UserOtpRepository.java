package com.employee.management.app.Repository;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.employee.management.app.Entities.AppUserDetails;
import com.employee.management.app.Entities.UserOtp;

@Repository
public interface UserOtpRepository extends JpaRepository<UserOtp, Long> {

    Optional<UserOtp> findByIdAndUserDetailsIdAndOtp(Long id, Long userId, String otp);

    void deleteByUserDetails(AppUserDetails userDetails);
}
