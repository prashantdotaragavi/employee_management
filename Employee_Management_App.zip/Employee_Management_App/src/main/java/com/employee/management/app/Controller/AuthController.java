package com.employee.management.app.Controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.employee.management.app.Payload.CreateEmployeeRequest;
import com.employee.management.app.Payload.ForgotPasswordRequest;
import com.employee.management.app.Payload.ForgotPasswordResponse;
import com.employee.management.app.Payload.JWTResponse;
import com.employee.management.app.Payload.LoginRequest;
import com.employee.management.app.Payload.ResetPasswordRequest;
import com.employee.management.app.Payload.ValidateOtpRequest;
import com.employee.management.app.Service.AuthService;
import com.employee.management.app.Service.EmployeeService;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    @Autowired
    private AuthService userService;
    
    @Autowired
    private EmployeeService employeeService;
    
    @PostMapping("/employees")
    public ResponseEntity<?> createEmployee(@RequestParam Integer id, @RequestBody CreateEmployeeRequest request) {
    	userService.createEmployeeCredentials(id, request.getPassword());
        return ResponseEntity.ok("Employee credentials created successfully.");
    }


   @PostMapping("/login")
    public ResponseEntity<JWTResponse> login(@RequestBody LoginRequest request) {
        String token = userService.loginDTO(request);
        JWTResponse jwtResponse = new JWTResponse();
        jwtResponse.setAccessToken(token);
        return ResponseEntity.ok(jwtResponse);
    }
    
    @PostMapping("/forgotPassword")
    public ResponseEntity<ForgotPasswordResponse> forgotPassword(@RequestBody ForgotPasswordRequest request) {
        ForgotPasswordResponse response = userService.forgotPassword(request);
        return ResponseEntity.ok(response);
    }
    
    @PostMapping("/validateOTP")
    public ResponseEntity<String> validateOtp(@RequestBody ValidateOtpRequest request) {
        userService.validateOtp(request);
        return ResponseEntity.ok("OTP validated successfully");
    }

    @PostMapping("/resetChangePassword")
    public ResponseEntity<String> resetPassword(@RequestBody ResetPasswordRequest request) {
        userService.resetPassword(request);
        return ResponseEntity.ok("Password changed successfully");
    }
}


