package com.employee.management.app.ServiceImpl;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import com.employee.management.app.Entities.Designation;
import com.employee.management.app.Entities.Employee;
import com.employee.management.app.Entities.EmployeeCommunication;
import com.employee.management.app.Entities.Organization;
import com.employee.management.app.Entities.PastExperience;
import com.employee.management.app.Exception.ResourceNotFoundException;
import com.employee.management.app.Exception.UniqueConstraintViolationException;
import com.employee.management.app.Payload.EmployeeCommunicationRequestDTO;
import com.employee.management.app.Payload.EmployeeCommunicationResponseDTO;
import com.employee.management.app.Payload.EmployeeRequestDTO;
import com.employee.management.app.Payload.EmployeeResponseByIdDTO;
import com.employee.management.app.Payload.PastExperienceRequestDTO;
import com.employee.management.app.Payload.PastExperienceResponseDTO;
import com.employee.management.app.Repository.DesignationRepository;
import com.employee.management.app.Repository.EmployeeCommunicationRepository;
import com.employee.management.app.Repository.EmployeeRepository;
import com.employee.management.app.Repository.OrganizationRepository;
import com.employee.management.app.Repository.PastExperienceRepository;
import com.employee.management.app.Service.EmployeeService;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class EmployeeServiceImpl implements EmployeeService {

    @Autowired
    private EmployeeRepository employeeRepository;
    
    @Autowired
    private DesignationRepository designationRepository;
    
    @Autowired
    private OrganizationRepository organizationRepository;   
    
    @Autowired
    private PastExperienceRepository pastExperienceRepository;
    
    @Autowired
    private EmployeeCommunicationRepository communicationRepository;

    @PersistenceContext
    private EntityManager entityManager;

    private final ModelMapper modelMapper;

    public EmployeeServiceImpl(ModelMapper modelMapper) {
        this.modelMapper = modelMapper;
    }

    @Override
    public Page<EmployeeResponseByIdDTO> getEmployees(String searchStr, Integer organizationId, Integer designationId, String doj, int page, int pageSize, Sort sort) {
    	
        PageRequest pageRequest = PageRequest.of(page - 1, pageSize, sort);
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<Employee> cq = cb.createQuery(Employee.class);
        Root<Employee> root = cq.from(Employee.class);

        Predicate predicate = cb.conjunction(); // Empty predicate to start

        if (searchStr != null && !searchStr.isEmpty()) {
            predicate = cb.and(predicate, cb.or(
                cb.like(root.get("firstName"), "%" + searchStr + "%"),
                cb.like(root.get("lastName"), "%" + searchStr + "%"),
                cb.like(root.get("empCode"), "%" + searchStr + "%")
            ));
        }
        if (organizationId != null) {
            predicate = cb.and(predicate, cb.equal(root.get("organization").get("id"), organizationId));
        }
        if (designationId != null) {
            predicate = cb.and(predicate, cb.equal(root.get("designation").get("id"), designationId));
        }
        if (doj != null && !doj.isEmpty()) {
            predicate = cb.and(predicate, cb.equal(root.get("doj"), LocalDate.parse(doj)));
        }
        cq.where(predicate);

        TypedQuery<Employee> query = entityManager.createQuery(cq);
        List<Employee> employees = query.getResultList();
        long totalRecords = countEmployees(predicate);

        Page<Employee> employeePage = new PageImpl<>(employees, pageRequest, totalRecords);
        
        return employeePage.map(this::mapToResponseDto);
    }


    private long countEmployees(Predicate predicate) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<Long> countQuery = cb.createQuery(Long.class);
        Root<Employee> root = countQuery.from(Employee.class);
        countQuery.select(cb.count(root)).where(predicate);
        return entityManager.createQuery(countQuery).getSingleResult();
    }

	private EmployeeResponseByIdDTO mapToResponseDto(Employee employee) {
		EmployeeResponseByIdDTO dto = modelMapper.map(employee, EmployeeResponseByIdDTO.class);
        

        dto.setEmailId(employee.getEmail());

        if (employee.getDesignation() != null) {
            dto.setDesignationId(employee.getDesignation().getId());
            dto.setDesignationName(employee.getDesignation().getDesignationName());
        } else {
            dto.setDesignationId(0); 
            dto.setDesignationName(null); 
        }

        return dto;
    }


    @Override
    public Employee createEmployee(EmployeeRequestDTO employeeRequestDTO) {
    	
    	if (employeeRepository.existsByEmpCode(employeeRequestDTO.getEmpCode())) {
            throw new UniqueConstraintViolationException("Employee code already exists.");
        }
        if (employeeRepository.existsByEmail(employeeRequestDTO.getEmail())) {
            throw new UniqueConstraintViolationException("Email already exists.");
        }
        if (employeeRepository.existsByPhone(employeeRequestDTO.getPhone())) {
            throw new UniqueConstraintViolationException("Phone number already exists.");
        }
        
        Organization organization = organizationRepository.findById(employeeRequestDTO.getOrganizationId()).orElseThrow(()->new RuntimeException("Organization not found"));
        Designation designation = designationRepository.findById(employeeRequestDTO.getDesignationId()).orElseThrow(()-> new RuntimeException("Designation not found"));
        
        String empCode = generateEmployeeCode(employeeRequestDTO.getOrganizationId());
    	
    	Employee employee = new Employee();
    	employee.setEmpCode(empCode);
    	employee.setFirstName(employeeRequestDTO.getFirstName());
    	employee.setLastName(employeeRequestDTO.getLastName());
    	employee.setFullName(employeeRequestDTO.getFirstName()+ ""+employeeRequestDTO.getLastName());
    	employee.setEmail(employeeRequestDTO.getEmail());
    	employee.setPhone(employeeRequestDTO.getPhone());
    	employee.setDoj(employeeRequestDTO.getDoj());
    	employee.setOrganization(organization);
    	employee.setDesignation(designation);
    	employee.setCreatedDate(LocalDateTime.now());
        employee.setActive(employeeRequestDTO.isActive());
         employeeRepository.save(employee);
        
        try {
        	for(EmployeeCommunicationRequestDTO communicationRequest: employeeRequestDTO.getCommunications()) {
        		EmployeeCommunication employeeCommunication = new EmployeeCommunication();
        		employeeCommunication.setEmployee(employee);;
        		employeeCommunication.setIsPermanent(communicationRequest.getIsPermanent());
        		employeeCommunication.setAddress(communicationRequest.getAddress());
        		employeeCommunication.setCity(communicationRequest.getCity());
        		employeeCommunication.setCountry(communicationRequest.getCountry());
        		employeeCommunication.setState(communicationRequest.getState());
        		employeeCommunication.setPincode(communicationRequest.getPincode());
        		communicationRepository.save(employeeCommunication);
        	}
		} catch (Exception e) {
			throw e;
		}
        
        for(PastExperienceRequestDTO pastExperienceRequestDTO: employeeRequestDTO.getPastExperiences()) {
        	int designationId = pastExperienceRequestDTO.getDesignationId();
        	
        	Designation pastDesignation = designationRepository.findById(designationId).orElseThrow(()-> new RuntimeException("Past Experience with Designation "+designationId+"not found") );
           PastExperience pastExperience = new PastExperience();
           pastExperience.setEmployee(employee);
           pastExperience.setCompanyName(pastExperienceRequestDTO.getCompanyName());
           pastExperience.setStartDate(pastExperienceRequestDTO.getStartDate());
           pastExperience.setEndDate(pastExperienceRequestDTO.getEndDate());
           pastExperience.setDesignation(pastDesignation);
           pastExperience.setResponsibilities(pastExperienceRequestDTO.getResponsibilities());
           pastExperienceRepository.save(pastExperience);
           
        }
        
        return employee;
        
    }
    
    private String generateEmployeeCode(Integer organizationId) {
    	 String orgShortCode= organizationRepository.findById(organizationId).map(Organization::getShortCode).orElseThrow(()->new RuntimeException("Organization not found"));
      int countByOrganizationId = employeeRepository.countByOrganizationId(organizationId);
      String empCode = String.format("%s%06d", orgShortCode, countByOrganizationId+1);
      return empCode;
    }

    @Override
	public EmployeeResponseByIdDTO getEmployeeById(Integer employeeId) throws ResourceNotFoundException {
	    Employee employee = employeeRepository.findById(employeeId)
	        .orElseThrow(() -> new ResourceNotFoundException("Employee not found with ID: " + employeeId));
	    
	    Optional<EmployeeCommunication> communicationDetails = communicationRepository.findById(employeeId);
	    Optional<PastExperience> pastExperienceDetails = pastExperienceRepository.findById(employeeId);
	    
	    return EmployeeResponseByIdDTO.builder()
	    		.id(employee.getId())
	    		.empCode(employee.getEmpCode())
	    		.firstName(employee.getFirstName())
	    		.lastName(employee.getLastName())
	    		.fullName(employee.getFirstName()+ " "+employee.getLastName())
	    		.emailId(employee.getEmail())
	    		.phone(employee.getPhone())
	    		.doj(employee.getDoj())
	    		.organizationId(employee.getOrganization()!=null?employee.getOrganization().getId():null)
	    		.organizationName(employee.getOrganization()!=null?employee.getOrganization().getName():null)
	    		.designationId(employee.getDesignation()!=null?employee.getDesignation().getId():null)
	    		.designationName(employee.getDesignation()!=null?employee.getDesignation().getDesignationName():null)
	    		.communications(communicationDetails.stream().map(c-> new EmployeeCommunicationResponseDTO(
	    				c.getIsPermanent(),
	    				c.getCity(),
	    				c.getCountry(),
	    				c.getPincode(),
	    				c.getAddress(),
	    				c.getPincode()
	    				)).collect(Collectors.toList()))
	    		.pastExperiences(pastExperienceDetails.stream().map(c-> new PastExperienceResponseDTO(
	    				employeeId, c.getCompanyName(),
	    				c.getStartDate(),
	    				c.getEndDate(),
	    				c.getDesignation().getId(),
	    			    c.getResponsibilities()
	    				)).collect(Collectors.toList()))
	    		.build();	
                
                
	}
	
	public Employee updateEmployee(Integer employeeId, EmployeeRequestDTO employeeDTO) {
        Employee employeeExistingId = employeeRepository.findById(employeeId).orElseThrow(()-> new RuntimeException("Employee Id not found with this "+ employeeId+"id"));
        employeeExistingId.setFirstName(employeeDTO.getFirstName());
        employeeExistingId.setLastName(employeeDTO.getLastName());
        employeeExistingId.setFullName(employeeDTO.getFirstName()+ employeeDTO.getLastName());
        employeeExistingId.setEmail(employeeDTO.getEmail());
        employeeExistingId.setPhone(employeeDTO.getPhone());
        employeeExistingId.setDoj(employeeDTO.getDoj());
        employeeExistingId.setOrganization(organizationRepository.findById(employeeDTO.getOrganizationId()).orElseThrow(()-> new RuntimeException("Organization not found with this "+employeeDTO.getOrganizationId()+"id")));
        employeeExistingId.setDesignation(designationRepository.findById(employeeDTO.getDesignationId()).orElseThrow(()-> new RuntimeException("Designation not found with this "+employeeDTO.getDesignationId()+"id")));
        
        communicationRepository.deleteById(employeeId);
        
        for(EmployeeCommunicationRequestDTO employeeCommunicationRequestDTO : employeeDTO.getCommunications() ) {
        	EmployeeCommunication  employeeCommunication = new EmployeeCommunication();
        	employeeCommunication.setEmployee(employeeExistingId);
        	employeeCommunication.setIsPermanent(employeeCommunicationRequestDTO.getIsPermanent());
        	employeeCommunication.setAddress(employeeCommunicationRequestDTO.getAddress());
        	employeeCommunication.setCity(employeeCommunicationRequestDTO.getCity());
        	employeeCommunication.setCountry(employeeCommunicationRequestDTO.getCountry());
        	employeeCommunication.setState(employeeCommunicationRequestDTO.getState());
        	employeeCommunication.setPincode(employeeCommunicationRequestDTO.getPincode());
           communicationRepository.save(employeeCommunication);
        }
        
        pastExperienceRepository.findById(employeeId);
        for(PastExperienceRequestDTO pastExperienceRequestDTO : employeeDTO.getPastExperiences()) {
        	PastExperience  pastExperience = new PastExperience();
        	pastExperience.setEmployee(employeeExistingId);
        	pastExperience.setCompanyName(pastExperienceRequestDTO.getCompanyName());
        	pastExperience.setStartDate(pastExperienceRequestDTO.getStartDate());
        	pastExperience.setEndDate(pastExperienceRequestDTO.getEndDate());
        	pastExperience.setDesignation(designationRepository.findById(employeeDTO.getDesignationId()).orElseThrow(()-> new RuntimeException("Designation with this id not found"+employeeDTO.getDesignationId()+"id")));
           pastExperienceRepository.save(pastExperience);
        }
        
        employeeRepository.save(employeeExistingId);
        
        return employeeRepository.save(employeeExistingId);
}

	@Override
	public Employee markEmployeeAsInactive(int employeeId) {
		Employee employeeStatus = employeeRepository.findById(employeeId).orElseThrow(()-> new RuntimeException("Employee not found with this "+employeeId+"id"));
		employeeStatus.setActive(false);
		return employeeRepository.save(employeeStatus);
	}// Need Active and inActive
	
	//
	
}
