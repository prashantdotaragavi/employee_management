package com.employee.management.app.Config;

import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import com.employee.management.app.Entities.AppUserDetails;
import com.employee.management.app.Entities.UserRole;
import com.employee.management.app.Repository.UserDetailsRepository;
import com.employee.management.app.Repository.UserRoleRepository;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class CustomUserDetailsService implements UserDetailsService{
	
	@Autowired
	private UserDetailsRepository userDetailsRepository;
	
	@Autowired
	private UserRoleRepository userRoleRepository;
	
//	@Autowired
//	private PasswordEncoder encoder;
	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		
	    AppUserDetails user = userDetailsRepository.findByUsername(username)
	        .orElseThrow(() -> new UsernameNotFoundException("User not found with username: " + username));
	    
	    Set<UserRole> userRoles = userRoleRepository.findByUserDetailsEmail(username); // Use the user object

	    Set<SimpleGrantedAuthority> authorities = userRoles.stream()
	        .map(role -> new SimpleGrantedAuthority(role.getRole().getRoleName()))
	        .collect(Collectors.toSet());

	    return new User(user.getUsername(), user.getPassword(), authorities); // Use user.getUsername()
	}


	

}
