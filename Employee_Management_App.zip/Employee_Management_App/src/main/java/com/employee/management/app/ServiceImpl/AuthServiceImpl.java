package com.employee.management.app.ServiceImpl;

import com.employee.management.app.Entities.Employee;

import com.employee.management.app.Entities.Role;
import com.employee.management.app.Config.JwtUtil;
import com.employee.management.app.Entities.AppUserDetails; // Change to your renamed class
import com.employee.management.app.Entities.UserOtp;
import com.employee.management.app.Entities.UserRole;
import com.employee.management.app.Payload.CreateEmployeeRequest;
import com.employee.management.app.Payload.ForgotPasswordRequest;
import com.employee.management.app.Payload.ForgotPasswordResponse;
import com.employee.management.app.Payload.LoginRequest;
import com.employee.management.app.Payload.ResetPasswordRequest;
import com.employee.management.app.Payload.ValidateOtpRequest;
import com.employee.management.app.Repository.EmployeeRepository;
import com.employee.management.app.Repository.RoleRepository;
import com.employee.management.app.Repository.UserDetailsRepository;
import com.employee.management.app.Repository.UserOtpRepository;
import com.employee.management.app.Repository.UserRoleRepository;
import com.employee.management.app.Service.AuthService;

import jakarta.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;
import java.time.LocalDateTime;
import java.util.Random;

@Service
public  class AuthServiceImpl implements AuthService {

    @Autowired
    private UserDetailsRepository userDetailsRepository;

    @Autowired
    private RoleRepository roleRepository;
    
    @Autowired
    private AuthenticationManager authenticationManager;
    

    @Autowired
    private UserRoleRepository userRoleRepository;

    @Autowired
    private UserOtpRepository userOtpRepository;
    
    @Autowired
    private EmployeeRepository employeeRepository;
    
    @Autowired
    private JwtUtil tokenProvider;



    @Transactional
    @Override
    public void createEmployeeCredentials(Integer employeeId, String password) {
        Employee employeeDetails = employeeRepository.findById(employeeId)
            .orElseThrow(() -> new RuntimeException("Employee Details not found with ID: " + employeeId));

        AppUserDetails user = new AppUserDetails();
        user.setUsername(employeeDetails.getEmail());
        user.setPassword(new BCryptPasswordEncoder().encode(password));
        user.setEmail(employeeDetails.getEmail());
        user.setPhone(employeeDetails.getPhone());
        user.setIsAuthenticated(true);
        user.setIsActive(true);
        user.setCreatedDate(LocalDateTime.now());

        AppUserDetails save = userDetailsRepository.save(user);

        Role role = roleRepository.findByRoleName("EMPLOYEE")
            .orElseThrow(() -> new RuntimeException("Role not found"));

        UserRole userRole = new UserRole();
        userRole.setUserDetails(save);
        userRole.setRole(role);

        userRoleRepository.save(userRole);
    }
    
	@Override
    public ForgotPasswordResponse forgotPassword(ForgotPasswordRequest request) {
        AppUserDetails user = userDetailsRepository.findByUsername(request.getUsername())
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.UNPROCESSABLE_ENTITY, "User not found"));

        // Generate 4-digit OTP
        String otp = String.valueOf(new Random().nextInt(9999 - 1000) + 1000);

        UserOtp userOtp = new UserOtp();
        userOtp.setUserDetails(user);
        userOtp.setOtp(otp);
        userOtp.setCreatedAt(LocalDateTime.now());

        UserOtp savedOtp = userOtpRepository.save(userOtp);

        return new ForgotPasswordResponse(user.getId(), savedOtp.getId(), otp);
    }

    @Override
    public void validateOtp(ValidateOtpRequest request) {
        UserOtp userOtp = userOtpRepository.findByIdAndUserDetailsIdAndOtp(request.getOtpId(), request.getUserId(), request.getOtp())
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.UNPROCESSABLE_ENTITY, "Invalid OTP"));

        userOtpRepository.delete(userOtp); // OTP is valid, delete record
    }

	@Override
	public void resetPassword(ResetPasswordRequest request) {
		
	}

	@Override
	public String loginDTO(LoginRequest loginRequest) {
		Authentication authenticate = authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(loginRequest.getUsername(), loginRequest.getPassword()));
		SecurityContextHolder.getContext().setAuthentication(authenticate);
		String token = tokenProvider.generateToken(authenticate);
		return token;
	}



	
}
